# 11_Praktikum_JukeBox
Code project used in the context of the PROG1 course.
